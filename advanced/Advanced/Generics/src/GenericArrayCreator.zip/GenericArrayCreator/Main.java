package GenericArrayCreator;

public class Main {

    public static void main(String[] args) {
        String[] names = ArrayCreator.create(5, "Pesho");

        Integer[] numbers = ArrayCreator.create(10, 50);

    }

}
