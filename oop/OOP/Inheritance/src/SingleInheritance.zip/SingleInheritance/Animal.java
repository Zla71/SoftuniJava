package SingleInheritance;

public class Animal {
    protected void eat() {
        System.out.println("eating...");
    }
}
