package restaurant;

import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        Cake cake = new Cake("Revane");
        System.out.println(cake.getCalories());
        System.out.println(cake.getGrams());
    }


}
