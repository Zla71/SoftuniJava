package hero;

public class Main {
    public static void main(String[] args) {
        Elf elf = new Elf("Pavel", 4);
        System.out.println(elf);

        SoulMaster soulMaster = new SoulMaster("Zlati", 34);
        System.out.println(soulMaster);
    }
}
