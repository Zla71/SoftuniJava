package Ferrari;

public interface Car {

    public String brakes();
    public String gas();
}
