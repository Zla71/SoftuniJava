package DefineAnInterfacePerson;

public interface Person {
    // getName() : String
    //getAge() : int

    public String getName();
    public int getAge();
}
