package MultipleImplementation;

public interface Birthable {
    public String getBirthDate();
}
