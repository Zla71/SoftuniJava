package Telephony;

public interface Callable {
    public String call();
}
