package CardSuit;

public enum CardSuit {

    // енъм стойности
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
