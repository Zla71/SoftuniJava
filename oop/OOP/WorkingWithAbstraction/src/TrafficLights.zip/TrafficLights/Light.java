package TrafficLights;

public enum Light {

    RED,
    GREEN,
    YELLOW;
}
