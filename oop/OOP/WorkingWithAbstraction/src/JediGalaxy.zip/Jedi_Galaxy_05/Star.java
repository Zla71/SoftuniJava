package Working_With_Abstraction_Exercise.Jedi_Galaxy_05;

public class Star {
    private int value;

    public Star(int value){
        this.value = value;
    }

    public int getValue() {
        return this.value;
    }
}